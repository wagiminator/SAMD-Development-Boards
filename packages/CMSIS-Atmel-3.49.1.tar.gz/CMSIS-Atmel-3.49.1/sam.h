/* ----------------------------------------------------------------------------
 *         SAM Software Package License
 * ----------------------------------------------------------------------------
 * Copyright (c) 2014, Atmel Corporation
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following condition is met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ----------------------------------------------------------------------------
 */
#ifndef _SAM_INCLUDED_
#define _SAM_INCLUDED_

#define part_is_defined(part) (defined(__ ## part ## __))

/*
 * ----------------------------------------------------------------------------
 * SAMD family
 * ----------------------------------------------------------------------------
 */

/* SAMD11 series */
#define SAMD11C14 ( \
    part_is_defined( SAMD11C14A ) )
#define SAMD11C	SAMD11C14

#define SAMD11D14 ( \
    part_is_defined( SAMD11D14AS ) || \
    part_is_defined( SAMD11D14AM ) || \
    part_is_defined( SAMD11D14AU ) )
#define SAMD11D	SAMD11D14

/* Entire SAMD11 series */
#define SAMD11_SERIES (SAMD11C14 || SAMD11D14)
#define SAMD11	SAMD11_SERIES

/* SAMD21 series */
#define SAMD21E15 ( \
    part_is_defined( SAMD21E15A ) || \
    part_is_defined( SAMD21E15B ) || \
    part_is_defined( SAMD21E15BU ) || \
    part_is_defined( SAMD21E15L ) )

#define SAMD21E16 ( \
    part_is_defined( SAMD21E16A ) || \
    part_is_defined( SAMD21E16B ) || \
    part_is_defined( SAMD21E16BU ) || \
    part_is_defined( SAMD21E16L ) )

#define SAMD21E17 ( \
    part_is_defined( SAMD21E17A ) || \
    part_is_defined( SAMD21E17D ) || \
    part_is_defined( SAMD21E17DU ) || \
    part_is_defined( SAMD21E17L ) )

#define SAMD21E18 ( \
    part_is_defined( SAMD21E18A ) )

#define SAMD21G15 ( \
    part_is_defined( SAMD21G15A ) || \
    part_is_defined( SAMD21G15B ) || \
    part_is_defined( SAMD21G15L ) )

#define SAMD21G16 ( \
    part_is_defined( SAMD21G16A ) || \
    part_is_defined( SAMD21G16B ) || \
    part_is_defined( SAMD21G16L ) )

#define SAMD21G17 ( \
    part_is_defined( SAMD21G17A ) || \
    part_is_defined( SAMD21G17AU ) )

#define SAMD21G18 ( \
    part_is_defined( SAMD21G18A ) || \
    part_is_defined( SAMD21G18AU ) )

#define SAMD21J15 ( \
    part_is_defined( SAMD21J15A ) || \
    part_is_defined( SAMD21J15B ) )

#define SAMD21J16 ( \
    part_is_defined( SAMD21J16A ) || \
    part_is_defined( SAMD21J16B ) )

#define SAMD21J17 ( \
    part_is_defined( SAMD21J17A ) )

#define SAMD21J18 ( \
    part_is_defined( SAMD21J18A ) )

/* Entire SAMD21E series */
#define SAMD21E_SERIES (SAMD21E15 || SAMD21E16 || SAMD21E17 || SAMD21E18)
#define SAMD21E	SAMD21E_SERIES

/* Entire SAMD21G series */
#define SAMD21G_SERIES (SAMD21G15 || SAMD21G16 || SAMD21G17 || SAMD21G18)
#define SAMD21G	SAMD21G_SERIES

/* Entire SAMD21J series */
#define SAMD21J_SERIES (SAMD21J15 || SAMD21J16 || SAMD21J17 || SAMD21J18)
#define SAMD21J	SAMD21J_SERIES

/* Entire SAMD21 series */
#define SAMD21_SERIES (SAMD21E15 || SAMD21E16 || SAMD21E17 || SAMD21E18 || SAMD21G15 || SAMD21G16 || SAMD21G17 || SAMD21G18 || SAMD21J15 || SAMD21J16 || SAMD21J17 || SAMD21J18)
#define SAMD21	SAMD21_SERIES

/* Entire SAMD family */
#define SAMD_SERIES (SAMD11_SERIES || SAMD21_SERIES)
#define SAMD  SAMD_SERIES

/*
 * ----------------------------------------------------------------------------
 * Whole SAM product line
 * ----------------------------------------------------------------------------
 */

#define SAM  SAMD_SERIES

/*
 * ----------------------------------------------------------------------------
 * Header inclusion
 * ----------------------------------------------------------------------------
 */

#if SAMD21_SERIES
#include "samd21/samd21.h"
#endif /* SAMD21_SERIES */

#if SAMD11_SERIES
#include "samd11/samd11.h"
#endif /* SAMD11_SERIES */

#endif
